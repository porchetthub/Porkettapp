# 🐷 PorkettApp

Trova i camioncini della porchetta in Abruzzo!

## Come pubblicare su Vercel (gratis, 5 minuti)

### Metodo A — Drag & Drop (più semplice, senza terminale)

1. Vai su [vercel.com](https://vercel.com) e crea un account gratuito
2. Clicca **"Add New Project"**
3. Clicca **"Import Third-Party Git Repository"** oppure usa **"Deploy from CLI"**
4. In alternativa: carica la cartella su GitHub e collega il repo a Vercel

### Metodo B — Con terminale (consigliato)

```bash
# 1. Entra nella cartella del progetto
cd porkettapp

# 2. Installa le dipendenze
npm install

# 3. Testa in locale (opzionale)
npm run dev
# Apri http://localhost:5173

# 4. Installa Vercel CLI
npm install -g vercel

# 5. Fai il deploy
vercel

# Segui le istruzioni: conferma il progetto, scegli il nome
# In 1 minuto hai il tuo URL tipo: porkettapp.vercel.app
```

### Metodo C — GitHub + Vercel (per aggiornamenti automatici)

```bash
# 1. Crea un repo su github.com
# 2. Carica il progetto
git init
git add .
git commit -m "Prima versione PorkettApp 🐷"
git remote add origin https://github.com/TUO-UTENTE/porkettapp.git
git push -u origin main

# 3. Su vercel.com → "Import Git Repository" → seleziona il repo
# Ogni volta che fai push, Vercel pubblica automaticamente!
```

## Sviluppo locale

```bash
npm install
npm run dev
```

Apri [http://localhost:5173](http://localhost:5173)

## Build di produzione

```bash
npm run build
```

Genera la cartella `dist/` pronta per il deploy.
